#!/usr/bin/env python3

import os
import sys
import time
import mysql.connector
from telethon.sync import TelegramClient
from telethon import errors
import utility as utl

for index, arg in enumerate(sys.argv):
    if index == 1:
        from_id = arg
    elif index == 2:
        status = arg
    elif index == 3:
        mbot_id = int(arg)
if len(sys.argv) != 4:
    print("Invalid parameters!")
    exit()

directory = os.path.dirname(os.path.abspath(__file__))
timestamp = int(time.time())
mydb = mysql.connector.connect(host = utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4")
cs = mydb.cursor(dictionary=True,buffered=True)

cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbot_id}")
row_mbots = cs.fetchone()
if row_mbots is None:
    exit()
try:
    client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}",api_id=row_mbots['api_id'],api_hash=row_mbots['api_hash'])
    client.connect()
    if status == 'check':
        try:
            if not client.is_user_authorized():
                cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
                utl.bot.send_message(chat_id=from_id,
                    text="❌ اکانت از دسترس خارج شد\n\n"+
                    "❗️ در صورت لزوم می توانید اکانت را حذف و دوباره لاگین کنید"
                )
            else:
                me = client.get_me()
                cs.execute(f"UPDATE {utl.mbots} SET user_id='{me.id}',status='submitted' WHERE id={row_mbots['id']}")
                utl.bot.send_message(chat_id=from_id,text=f"وضعیت: فعال ✅")
        except Exception as e:
            if "database is locked" in str(e):
                utl.bot.send_message(chat_id=from_id,text="❌ پروسس ها را کیل و ربات را دوباره ران کنید!")
            else:
                utl.bot.send_message(chat_id=from_id,text="❌ مشکلی پیش آمده، دوباره تلاش کنید!")
            print("Error check status: " + str(e))
    elif status == 'first_level':
        if client.is_user_authorized():
            me = client.get_me()
            cs.execute(f"UPDATE {utl.mbots} SET user_id='{me.id}',status='submitted' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
            utl.bot.send_message(chat_id=from_id,text="✅ اکانت قبلا ثبت شده")
            exit()
        me = client.send_code_request(phone=row_mbots['phone'])
        cs.execute(f"UPDATE {utl.mbots} SET phone_code_hash='{me.phone_code_hash}',code=null,password=null WHERE id={row_mbots['id']}")
        cs.execute(f"UPDATE {utl.users} SET step='add_acc;code;{row_mbots['id']}' WHERE user_id='{from_id}'")
        utl.bot.send_message(chat_id=from_id,text=
            "پنل ادمین » افزودن اکانت » ارسال کد و پسورد:\n\n"+
            "❕ اگر پسورد نداشت فقط کد را ارسال کنید مثال:\n"+
            "12345\n\n"+
            "❕ اگر اکانت پسورد دارد هر کدام در یک خط مثال:\n"+
            "code\n"+
            "password"
        )
    elif status == 'code':
        try:
            me = client.sign_in(phone=row_mbots['phone'],phone_code_hash=row_mbots['phone_code_hash'],code=row_mbots['code'])
        except errors.SessionPasswordNeededError as e:
            if row_mbots['password'] is None:
                cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
                utl.bot.send_message(chat_id=from_id,
                    text="❌ اکانت دارای پسورد می باشد!\n\n" +
                        "❕ همانند زیر هر کدام را در یک خط ارسال کنید:\n"+
                        "code\n"+
                        "password"
                )
                exit()
            else:
                me = client.sign_in(password=row_mbots['password'])
        cs.execute(f"UPDATE {utl.mbots} SET user_id='{me.id}',status='submitted' WHERE id={row_mbots['id']}")
        cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
        utl.bot.send_message(chat_id=from_id,text="✅ با موفقیت ثبت شد")
except Exception as e:
    cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
    cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
    print("Error2: " + str(e))
    error = str(e)
    if "database is locked" in error:
        utl.bot.send_message(chat_id=from_id,text="❌ پروسس ها را کیل و ربات را دوباره ران کنید!")
    elif "You have tried logging in too many times" in error:
        utl.bot.send_message(chat_id=from_id,text="❌ شماره به دلیل تلاش بیش از حد بلاک شده، 24 ساعت بعد دوباره تلاش کنید!")
    elif "The password (and thus its hash value) you entered is invalid" in error:
        utl.bot.send_message(chat_id=from_id,text="❌ پسورد وارد شده اشتباه است!")
    else:
        utl.bot.send_message(chat_id=from_id,text="❌ مشکلی پیش آمده، دوباره تلاش کنید!")
finally:
    try:
        client.disconnect()
    except:
        pass
