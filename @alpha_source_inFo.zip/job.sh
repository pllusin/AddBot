#!/bin/sh
python3 bot.py &
python3 cr.settings.py &
python3 tl.add-to-group.py &